class Entree:
     def __init__(self):
        self.index = ''
        self.name = ''
        self.description = ''
        self.long_winded_description = ''
        self.price = ''

