import urllib2
fd = urllib2.urlopen('http://mehfilindian.com/LunchMenuTakeOut.htm')
print 'squash' in fd.read()
